package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage {

    WebDriver driver;

    By emailField = By.id("email");
    By passwordField = By.id("passwd");
    By loginButton = By.id("SubmitLogin");

    public LoginPage(WebDriver driver) {
        this.driver = driver;
    }

    public void ingresarEmail(String email) {
        driver.findElement(emailField).sendKeys(email);
    }

    public void ingresarPassword(String password) {
        driver.findElement(passwordField).sendKeys(password);
    }

    public void clickLogin() {
        driver.findElement(loginButton).click();
    }

    public void login(String email, String password) {
        ingresarEmail(email);
        ingresarPassword(password);
        clickLogin();
    }
}